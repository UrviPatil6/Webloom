<?php
/**
 * Plugin Name: Elementor Full Width REST Fix
 * Description: Properly enables Elementor Full Width page layout via WordPress REST API without breaking Elementor UI.
 * Version: 1.1.0
 * Author: Troika Tech
 */

if (!defined('ABSPATH')) exit;

/**
 * 1. Allow _wp_page_template via REST API
 */
add_action('init', function () {
    register_post_meta('page', '_wp_page_template', [
        'show_in_rest'  => true,
        'single'        => true,
        'type'          => 'string',
        'auth_callback' => function () {
            return current_user_can('edit_pages');
        },
    ]);
});

/**
 * 2. Tell WordPress these Elementor templates are valid
 *    (THIS fixes the blank dropdown issue)
 */
add_filter('theme_page_templates', function ($templates) {
    $templates['elementor_full_width'] = 'Elementor Full Width';
    $templates['elementor_canvas']     = 'Elementor Canvas';
    $templates['elementor_theme']      = 'Elementor Theme';
    return $templates;
}, 20); // Priority 20 to ensure it runs after Elementor

/**
 * 2b. Force Elementor to recognize the page layout
 *     Elementor UI reads from get_page_template_slug() which checks _wp_page_template
 */
add_action('elementor/editor/before_enqueue_scripts', function () {
    global $post;
    if ($post && get_post_meta($post->ID, '_wp_page_template', true) === 'elementor_full_width') {
        // Ensure Elementor page settings reflect the template
        $page_settings = get_post_meta($post->ID, '_elementor_page_settings', true);
        if (empty($page_settings) || !isset($page_settings['page_layout'])) {
            $page_settings = $page_settings ?: [];
            $page_settings['page_layout'] = 'elementor_full_width';
            update_post_meta($post->ID, '_elementor_page_settings', $page_settings);
        }
    }
});

/**
 * 3. Sync REST updates cleanly
 */
add_action('rest_after_insert_page', function ($post, $request) {
    if (isset($request['meta']['_wp_page_template'])) {
        update_post_meta(
            $post->ID,
            '_wp_page_template',
            sanitize_text_field($request['meta']['_wp_page_template'])
        );
    }
}, 10, 2);
